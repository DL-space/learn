<template>
		<div id="carttp">
			<header class="top_bar">
		    <a onclick="window.history.go(-1)" class="icon_back"></a>
		    <h3 class="cartname">购物车</h3>
		    <a href="#" class="icon_menu"></a>
		</header>
		</div>

</template>