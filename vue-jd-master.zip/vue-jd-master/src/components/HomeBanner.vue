<template>
	<div class="home_ban">
		<div class="m_banner clearfix" id="my_banner">
                <ul class="banner_box">
                    <li><img src="../assets/images/l8.jpg" alt="" /></li>
                    <li><img src="../assets/images/l1.jpg" alt="" /></li>
                    <li><img src="../assets/images/l2.jpg" alt="" /></li>
                    <li><img src="../assets/images/l3.jpg" alt="" /></li>
                    <li><img src="../assets/images/l4.jpg" alt="" /></li>
                    <li><img src="../assets/images/l5.jpg" alt="" /></li>
                    <li><img src="../assets/images/l6.jpg" alt="" /></li>
                    <li><img src="../assets/images/l7.jpg" alt="" /></li>
                    <li><img src="../assets/images/l8.jpg" alt="" /></li>
                    <li><img src="../assets/images/l1.jpg" alt="" /></li>
                </ul>
                <ul class="point_box">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
	</div>
</template>