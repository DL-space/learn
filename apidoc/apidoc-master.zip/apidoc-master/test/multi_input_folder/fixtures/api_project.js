define({
  "name": "Multiple Input Folder Test",
  "version": "1.0.0",
  "description": "Example of feeding apidoc from multiple input folder locations",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-01-13T17:59:32.277Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
