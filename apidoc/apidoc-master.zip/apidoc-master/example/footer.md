# Example text from footer.md

This text is from file "footer.md".

## HowTo include

Watch header.md for further information.
