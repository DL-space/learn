import Yimg from './src/Img.vue'

export default Yimg