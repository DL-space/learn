import YGimg from './src/YGimg.vue'

export default YGimg