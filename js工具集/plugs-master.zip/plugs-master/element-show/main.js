/**
 * Created by Steven on 2016-10-09.
 */
window.onload = function () {
    var oUl = document.getElementById('app');
    //在这里传id在一定程度上提高效率，缩小查找范围，n-show属性可以自定义，默认为n-show
    //该属性为true显示，false不显示
    show('app','n-show')
}