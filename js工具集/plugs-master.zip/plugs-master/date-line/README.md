#### 垂直时间轴

-演示地址：<https://stevenzwzhai.github.io/plugins/date-line/>

-效果：点击某个时间节点，则该时间节点滑动到中间位置，并且新的时间节点补充之前时间节点位置
