const {
    singerCollect
} = require('./code');

singerCollect();