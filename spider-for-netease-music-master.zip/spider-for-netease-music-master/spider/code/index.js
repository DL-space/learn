const singerCollect = require('./singer');
const songCollect=require('./song');
module.exports = {
    singerCollect,
    songCollect
}