const {
    songCollect
} = require('./code');

songCollect();