const singerConfig = require('./singer');
const database = require('./mysql');
const songConfig=require('./song');
module.exports = {
    singerConfig,
    database,
    songConfig
}