# vue2_cart
vue2.0实现基本购物车效果
