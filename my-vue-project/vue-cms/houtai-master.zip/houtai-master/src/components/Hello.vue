<template>
  <div id="hello">
    <el-button>默认按钮</el-button>
  </div>

</template>

<script>
  import Vue from 'vue'
  import Element from 'element-ui'
  import 'element-ui/lib/theme-default/index.css'

  Vue.use(Element)

export default {
  name: 'hello'
}
</script>

