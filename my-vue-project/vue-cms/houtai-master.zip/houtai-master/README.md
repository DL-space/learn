# 基于vue和Element的后台管理系统
> 升级为vue@2.16 + Element@1.0.9

* [在线DEMO](http://dahouge.oschina.io/houtai/dist/#/activePublic)
* [详细教程](http://www.jianshu.com/p/d87d7140944e)
## Build Setup

``` bash
# 克隆项目 
 git clone https://github.com/WebCodeFarmer/houtai.git

# 查看目录
ls

# 进入项目目录
cd houtai

# 安装开发依赖,推荐使用npm安装，cnpm可能会丢包，或者各种兼容性问题
npm install

# 运行
npm run dev

# 打包压缩
npm run build
```

